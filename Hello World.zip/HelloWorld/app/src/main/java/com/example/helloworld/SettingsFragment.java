package com.example.helloworld;

import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {
}
