package com.example.helloworld;

public class Constants {

    static final String KEY_NAME = "name";
    static final String KEY_EMAIL = "email";
    static final String KEY_USERNAME = "userName";
    static final String KEY_DATE = "date";
    static final String KEY_BIRTHDATE_BUTTON = "Date of Birth";
    static final String KEY_OCCUPATION = "Occupation";
    static final String KEY_SELF_DESCRIPTION = "Self description";
    static final String KEY_AGE = "age";
}
